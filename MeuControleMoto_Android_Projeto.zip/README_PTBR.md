# Meu Controle Moto — Android

Projeto Android que empacota o Meu Controle Moto V5 em um aplicativo nativo com WebView.

## Como gerar o APK sem instalar Android Studio

1. Crie uma conta no GitHub.
2. Crie um repositório novo, por exemplo `MeuControleMoto`.
3. Envie todos os arquivos desta pasta para o repositório.
4. Abra a aba **Actions**.
5. Escolha **Build APK** e execute **Run workflow** (ou faça um commit na branch `main`).
6. Quando terminar, abra a execução concluída e baixe o artefato **MeuControleMoto-debug**.
7. Dentro do ZIP estará `app-debug.apk`.
8. No Android, toque no APK e permita a instalação quando o sistema solicitar.

## O que já está dentro

- Nome do app: Meu Controle Moto
- Pacote: com.leon.controlemoto
- Tela em modo retrato
- JavaScript + armazenamento local
- V5 completa dentro de `app/src/main/assets/meu_controle_moto_v5.html`
- Workflow automático para gerar APK

## Importante

O app usa armazenamento local do WebView. Antes de desinstalar o aplicativo, use a função **Exportar backup** dentro do Meu Controle Moto para guardar seus dados.
